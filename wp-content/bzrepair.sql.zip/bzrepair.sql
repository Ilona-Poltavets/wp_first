-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 18, 2023 at 09:22 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bzrepair`
--

-- --------------------------------------------------------

--
-- Table structure for table `wpt_actionscheduler_actions`
--

CREATE TABLE `wpt_actionscheduler_actions` (
  `action_id` bigint UNSIGNED NOT NULL,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `attempts` int NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_actionscheduler_actions`
--

INSERT INTO `wpt_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(79, 'action_scheduler/migration_hook', 'complete', '2023-04-17 21:10:26', '2023-04-17 21:10:26', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1681765826;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1681765826;}', 1, 1, '2023-04-17 21:10:57', '2023-04-17 21:10:57', 0, NULL),
(80, 'wp_mail_smtp_summary_report_email', 'pending', '2023-04-24 14:00:00', '2023-04-24 14:00:00', '[null]', 'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1682344800;s:18:\"\0*\0first_timestamp\";i:1682344800;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1682344800;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(81, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[1]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 2, 1, '2023-04-17 21:11:26', '2023-04-17 21:11:26', 0, NULL),
(82, 'action_scheduler/migration_hook', 'pending', '2023-04-17 21:12:25', '2023-04-17 21:12:25', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1681765945;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1681765945;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_actionscheduler_claims`
--

CREATE TABLE `wpt_actionscheduler_claims` (
  `claim_id` bigint UNSIGNED NOT NULL,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_actionscheduler_groups`
--

CREATE TABLE `wpt_actionscheduler_groups` (
  `group_id` bigint UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_actionscheduler_groups`
--

INSERT INTO `wpt_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wp_mail_smtp');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_actionscheduler_logs`
--

CREATE TABLE `wpt_actionscheduler_logs` (
  `log_id` bigint UNSIGNED NOT NULL,
  `action_id` bigint UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_actionscheduler_logs`
--

INSERT INTO `wpt_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 79, 'action created', '2023-04-17 21:09:26', '2023-04-17 21:09:26'),
(2, 79, 'action started via WP Cron', '2023-04-17 21:10:57', '2023-04-17 21:10:57'),
(3, 79, 'action complete via WP Cron', '2023-04-17 21:10:57', '2023-04-17 21:10:57'),
(4, 80, 'action created', '2023-04-17 21:10:59', '2023-04-17 21:10:59'),
(5, 81, 'action created', '2023-04-17 21:11:06', '2023-04-17 21:11:06'),
(6, 82, 'action created', '2023-04-17 21:11:25', '2023-04-17 21:11:25'),
(7, 81, 'action started via WP Cron', '2023-04-17 21:11:25', '2023-04-17 21:11:25'),
(8, 81, 'action complete via WP Cron', '2023-04-17 21:11:26', '2023-04-17 21:11:26');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_commentmeta`
--

CREATE TABLE `wpt_commentmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_comments`
--

CREATE TABLE `wpt_comments` (
  `comment_ID` bigint UNSIGNED NOT NULL,
  `comment_post_ID` bigint UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_comments`
--

INSERT INTO `wpt_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2023-04-11 14:25:46', '2023-04-11 14:25:46', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_links`
--

CREATE TABLE `wpt_links` (
  `link_id` bigint UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_options`
--

CREATE TABLE `wpt_options` (
  `option_id` bigint UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_options`
--

INSERT INTO `wpt_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://bzrepair', 'yes'),
(2, 'home', 'http://bzrepair', 'yes'),
(3, 'blogname', 'BZ Diesel Repaire', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'qwerty@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:113:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"gallery/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"gallery/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"gallery/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"gallery/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"gallery/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"gallery/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"gallery/([^/]+)/embed/?$\";s:43:\"index.php?maxgallery=$matches[1]&embed=true\";s:28:\"gallery/([^/]+)/trackback/?$\";s:37:\"index.php?maxgallery=$matches[1]&tb=1\";s:36:\"gallery/([^/]+)/page/?([0-9]{1,})/?$\";s:50:\"index.php?maxgallery=$matches[1]&paged=$matches[2]\";s:43:\"gallery/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?maxgallery=$matches[1]&cpage=$matches[2]\";s:32:\"gallery/([^/]+)(?:/([0-9]+))?/?$\";s:49:\"index.php?maxgallery=$matches[1]&page=$matches[2]\";s:24:\"gallery/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"gallery/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"gallery/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"gallery/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"gallery/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"gallery/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:64:\"D:\\OSPanel\\domains\\bzrepair/wp-content/themes/bzrepair/style.css\";i:2;s:0:\"\";}', 'no'),
(40, 'template', 'bzrepair', 'yes'),
(41, 'stylesheet', 'bzrepair', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:2:{s:29:\"slick-slider/slick-slider.php\";a:2:{i:0;s:17:\"Slick_Slider_Main\";i:1;s:9:\"uninstall\";}s:26:\"post-smtp/postman-smtp.php\";a:2:{i:0;s:8:\"Freemius\";i:1;s:22:\"_uninstall_plugin_hook\";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '5', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1696775146', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wpt_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'user_count', '1', 'no'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:13:\"array_version\";i:3;}', 'yes'),
(105, 'cron', 'a:7:{i:1681842346;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1681871146;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1681871176;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1681914346;a:2:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1681914376;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1681914419;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_recent-posts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(117, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(119, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(121, 'recovery_keys', 'a:0:{}', 'yes'),
(122, 'theme_mods_twentytwentythree', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1681225028;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(124, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(125, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-6.2.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-6.2-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-6.2-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"6.2\";s:7:\"version\";s:3:\"6.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"6.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1681828314;s:15:\"version_checked\";s:3:\"6.2\";s:12:\"translations\";a:0:{}}', 'no'),
(129, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1681828316;s:7:\"checked\";a:1:{s:8:\"bzrepair\";s:0:\"\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(130, 'can_compress_scripts', '1', 'no'),
(135, 'finished_updating_comment_type', '1', 'yes'),
(140, 'current_theme', '', 'yes'),
(141, 'theme_mods_bzrepair', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:3:\"top\";i:2;s:6:\"footer\";i:3;}s:18:\"custom_css_post_id\";i:-1;s:11:\"custom_logo\";i:5;}', 'yes'),
(142, 'theme_switched', '', 'yes'),
(149, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(157, '_site_transient_timeout_browser_c3fcd9e52fd775c43c9553a961bfc52c', '1681836954', 'no'),
(158, '_site_transient_browser_c3fcd9e52fd775c43c9553a961bfc52c', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:9:\"111.0.0.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(159, '_site_transient_timeout_php_check_9522db31646a2e4672d744b6f556967b', '1681836954', 'no'),
(160, '_site_transient_php_check_9522db31646a2e4672d744b6f556967b', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(163, 'site_logo', '5', 'yes'),
(168, '_transient_health-check-site-status-result', '{\"good\":15,\"recommended\":6,\"critical\":0}', 'yes'),
(184, 'recently_activated', 'a:5:{s:29:\"wp-mail-smtp/wp_mail_smtp.php\";i:1681765906;s:26:\"post-smtp/postman-smtp.php\";i:1681765884;s:31:\"wp-google-maps/wpGoogleMaps.php\";i:1681332581;s:29:\"slick-slider/slick-slider.php\";i:1681329340;s:27:\"maxgalleria/maxgalleria.php\";i:1681329338;}', 'yes'),
(199, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(203, 'mg_hide_presets', 'on', 'yes'),
(204, 'widget_maxgalleria-gallery-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(205, 'widget_maxgalleria-gallery-thumb-widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(206, 'mg_current_gallery', '31', 'no'),
(210, 'category_children', 'a:0:{}', 'yes'),
(215, 'wpcf7', 'a:2:{s:7:\"version\";s:7:\"5.7.5.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1681330338;s:7:\"version\";s:7:\"5.7.5.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(221, 'wpgmza_db_version', '9.0.18', 'yes'),
(222, 'wpgmza_global_settings', '{\"engine\":\"google-maps\",\"internal_engine\":\"atlas-novus\",\"google_maps_api_key\":false,\"default_marker_icon\":\"http:\\/\\/bzrepair\\/wp-content\\/plugins\\/wp-google-maps\\/images\\/spotlight-poi3.png\",\"developer_mode\":false,\"user_interface_style\":\"default\",\"wpgmza_gdpr_enabled\":1,\"wpgmza_gdpr_default_notice\":\"<p>\\r\\n\\tI agree for my personal data to be processed by <span name=\\\"wpgmza_gdpr_company_name\\\"><\\/span>, for the purpose(s) of <span name=\\\"wpgmza_gdpr_retention_purpose\\\"><\\/span>.\\r\\n<\\/p>\\r\\n\\r\\n<p>\\t\\r\\n\\tI agree for my personal data, provided via map API calls, to be processed by the API provider, for the purposes of geocoding (converting addresses to coordinates), reverse geocoding and\\tgenerating directions.\\r\\n<\\/p>\\r\\n<p>\\r\\n\\tSome visual components of WP Go Maps use 3rd party libraries which are loaded over the network. At present the libraries are Google Maps, Open Street Map, jQuery DataTables and FontAwesome. When loading resources over a network, the 3rd party server will receive your IP address and User Agent string amongst other details. Please refer to the Privacy Policy of the respective libraries for details on how they use data and the process to exercise your rights under the GDPR regulations.\\r\\n<\\/p>\\r\\n<p>\\r\\n\\tWP Go Maps uses jQuery DataTables to display sortable, searchable tables, such as that seen in the Advanced Marker Listing and on the Map Edit Page. jQuery DataTables in certain circumstances uses a cookie to save and later recall the \\\"state\\\" of a given table - that is, the search term, sort column and order and current page. This data is held in local storage and retained until this is cleared manually. No libraries used by WP Go Maps transmit this information.\\r\\n<\\/p>\\r\\n<p>\\r\\n\\tPlease <a href=\\\"https:\\/\\/developers.google.com\\/maps\\/terms\\\">see here<\\/a> and <a href=\\\"https:\\/\\/maps.google.com\\/help\\/terms_maps.html\\\">here<\\/a> for Google\'s terms. Please also see <a href=\\\"https:\\/\\/policies.google.com\\/privacy?hl=en-GB&amp;gl=uk\\\">Google\'s Privacy Policy<\\/a>. We do not send the API provider any personally identifying information, or information that could uniquely identify your device.\\r\\n<\\/p>\\r\\n<p>\\r\\n\\tWhere this notice is displayed in place of a map, agreeing to this notice will store a cookie recording your agreement so you are not prompted again.\\r\\n<\\/p>\",\"wpgmza_gdpr_company_name\":\"BZ Diesel Repaire\",\"wpgmza_gdpr_retention_purpose\":\"displaying map tiles, geocoding addresses and calculating and display directions.\",\"wpgmza_gdpr_button_label\":\"I agree\",\"wpgmza_marker_xml_location\":\"D:\\\\OSPanel\\\\domains\\\\bzrepair\\\\wp-content\\\\uploads\\\\wp-google-maps\\\\\",\"wpgmza_marker_xml_url\":\"http:\\/\\/bzrepair\\/wp-content\\/uploads\\/wp-google-maps\\/\"}', 'yes'),
(223, 'WPGMZA_OTHER_SETTINGS', 'a:13:{s:6:\"engine\";s:11:\"google-maps\";s:15:\"internal_engine\";s:11:\"atlas-novus\";s:19:\"google_maps_api_key\";b:0;s:19:\"default_marker_icon\";s:75:\"http://bzrepair/wp-content/plugins/wp-google-maps/images/spotlight-poi3.png\";s:14:\"developer_mode\";b:0;s:20:\"user_interface_style\";s:7:\"default\";s:19:\"wpgmza_gdpr_enabled\";i:1;s:26:\"wpgmza_gdpr_default_notice\";s:1960:\"<p>\r\n	I agree for my personal data to be processed by <span name=\"wpgmza_gdpr_company_name\"></span>, for the purpose(s) of <span name=\"wpgmza_gdpr_retention_purpose\"></span>.\r\n</p>\r\n\r\n<p>	\r\n	I agree for my personal data, provided via map API calls, to be processed by the API provider, for the purposes of geocoding (converting addresses to coordinates), reverse geocoding and	generating directions.\r\n</p>\r\n<p>\r\n	Some visual components of WP Go Maps use 3rd party libraries which are loaded over the network. At present the libraries are Google Maps, Open Street Map, jQuery DataTables and FontAwesome. When loading resources over a network, the 3rd party server will receive your IP address and User Agent string amongst other details. Please refer to the Privacy Policy of the respective libraries for details on how they use data and the process to exercise your rights under the GDPR regulations.\r\n</p>\r\n<p>\r\n	WP Go Maps uses jQuery DataTables to display sortable, searchable tables, such as that seen in the Advanced Marker Listing and on the Map Edit Page. jQuery DataTables in certain circumstances uses a cookie to save and later recall the \"state\" of a given table - that is, the search term, sort column and order and current page. This data is held in local storage and retained until this is cleared manually. No libraries used by WP Go Maps transmit this information.\r\n</p>\r\n<p>\r\n	Please <a href=\"https://developers.google.com/maps/terms\">see here</a> and <a href=\"https://maps.google.com/help/terms_maps.html\">here</a> for Google\'s terms. Please also see <a href=\"https://policies.google.com/privacy?hl=en-GB&amp;gl=uk\">Google\'s Privacy Policy</a>. We do not send the API provider any personally identifying information, or information that could uniquely identify your device.\r\n</p>\r\n<p>\r\n	Where this notice is displayed in place of a map, agreeing to this notice will store a cookie recording your agreement so you are not prompted again.\r\n</p>\";s:24:\"wpgmza_gdpr_company_name\";s:17:\"BZ Diesel Repaire\";s:29:\"wpgmza_gdpr_retention_purpose\";s:81:\"displaying map tiles, geocoding addresses and calculating and display directions.\";s:24:\"wpgmza_gdpr_button_label\";s:7:\"I agree\";s:26:\"wpgmza_marker_xml_location\";s:62:\"D:\\OSPanel\\domains\\bzrepair\\wp-content\\uploads\\wp-google-maps\\\";s:21:\"wpgmza_marker_xml_url\";s:50:\"http://bzrepair/wp-content/uploads/wp-google-maps/\";}', 'yes'),
(224, 'wpgmza_xml_location', 'D:\\OSPanel\\domains\\bzrepair\\wp-content\\uploads\\wp-google-maps\\', 'yes'),
(225, 'wpgmza_xml_url', 'http://bzrepair/wp-content/uploads/wp-google-maps/', 'yes'),
(226, 'wpgmza_temp_api', 'AIzaSyDo_fG7DXBOVvdhlrLa-PHREuFDpTklWhY', 'yes'),
(227, 'wpgmza-first-run', '2023-04-12T20:48:16+0000', 'yes'),
(228, 'wpgmza_welcome_screen_done', '1', 'yes'),
(229, 'widget_wpgmza_map_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(276, 'acf_version', '6.1.4', 'yes'),
(277, '_site_transient_timeout_browser_d9c544d0aaddfd20c051a0811f2f382d', '1682165228', 'no'),
(278, '_site_transient_browser_d9c544d0aaddfd20c051a0811f2f382d', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:9:\"112.0.0.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(323, 'fs_active_plugins', 'O:8:\"stdClass\":0:{}', 'yes'),
(324, 'fs_debug_mode', '', 'yes'),
(325, 'fs_accounts', 'a:6:{s:21:\"id_slug_type_path_map\";a:1:{i:10461;a:2:{s:4:\"slug\";s:9:\"post-smtp\";s:4:\"type\";s:6:\"plugin\";}}s:11:\"plugin_data\";a:1:{s:9:\"post-smtp\";a:16:{s:16:\"plugin_main_file\";O:8:\"stdClass\":1:{s:9:\"prev_path\";s:26:\"post-smtp/postman-smtp.php\";}s:20:\"is_network_activated\";b:0;s:17:\"install_timestamp\";i:1681765535;s:17:\"was_plugin_loaded\";b:1;s:21:\"is_plugin_new_install\";b:1;s:16:\"sdk_last_version\";N;s:11:\"sdk_version\";s:5:\"2.5.5\";s:16:\"sdk_upgrade_mode\";b:1;s:18:\"sdk_downgrade_mode\";b:0;s:19:\"plugin_last_version\";N;s:14:\"plugin_version\";s:5:\"2.4.8\";s:19:\"plugin_upgrade_mode\";b:1;s:21:\"plugin_downgrade_mode\";b:0;s:17:\"connectivity_test\";a:6:{s:12:\"is_connected\";N;s:4:\"host\";s:8:\"bzrepair\";s:9:\"server_ip\";s:9:\"127.0.0.1\";s:9:\"is_active\";b:1;s:9:\"timestamp\";i:1681765535;s:7:\"version\";s:5:\"2.4.8\";}s:15:\"prev_is_premium\";b:0;s:21:\"is_pending_activation\";b:1;}}s:13:\"file_slug_map\";a:1:{s:26:\"post-smtp/postman-smtp.php\";s:9:\"post-smtp\";}s:7:\"plugins\";a:1:{s:9:\"post-smtp\";O:9:\"FS_Plugin\":24:{s:2:\"id\";s:5:\"10461\";s:7:\"updated\";N;s:7:\"created\";N;s:22:\"\0FS_Entity\0_is_updated\";b:0;s:10:\"public_key\";s:32:\"pk_28fcefa3d0ae86f8cdf6b7f71c0cc\";s:10:\"secret_key\";N;s:16:\"parent_plugin_id\";N;s:5:\"title\";s:9:\"Post SMTP\";s:4:\"slug\";s:9:\"post-smtp\";s:12:\"premium_slug\";s:17:\"post-smtp-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";b:0;s:19:\"is_wp_org_compliant\";b:1;s:22:\"premium_releases_count\";N;s:4:\"file\";s:26:\"post-smtp/postman-smtp.php\";s:7:\"version\";s:5:\"2.4.8\";s:11:\"auto_update\";N;s:4:\"info\";N;s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:9:\"bundle_id\";s:5:\"10910\";s:17:\"bundle_public_key\";s:32:\"pk_c5110ef04ba30cd57dd970a269a1a\";s:17:\"opt_in_moderation\";N;}}s:9:\"unique_id\";s:32:\"ee500647ee4d636fb7c8866146916889\";s:13:\"admin_notices\";a:1:{s:9:\"post-smtp\";a:0:{}}}', 'yes'),
(326, 'postman_options', 'a:1:{s:21:\"fallback_smtp_enabled\";s:2:\"no\";}', 'yes'),
(327, 'postman_state', 'a:3:{s:15:\"locking_enabled\";b:0;s:12:\"install_date\";i:1681765537;s:7:\"version\";s:5:\"2.4.8\";}', 'yes'),
(328, 'fs_api_cache', 'a:0:{}', 'no'),
(332, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1681828316;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:6:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"6.1.4\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.6.1.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=2892919\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=2892919\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.7\";}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"5.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:60:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=2818463\";s:2:\"1x\";s:60:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=2818463\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/akismet/assets/banner-1544x500.png?rev=2900731\";s:2:\"1x\";s:62:\"https://ps.w.org/akismet/assets/banner-772x250.png?rev=2900731\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.0\";}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:7:\"5.7.5.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/contact-form-7.5.7.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.0\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/hello-dolly/assets/banner-1544x500.jpg?rev=2645582\";s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:26:\"post-smtp/postman-smtp.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:23:\"w.org/plugins/post-smtp\";s:4:\"slug\";s:9:\"post-smtp\";s:6:\"plugin\";s:26:\"post-smtp/postman-smtp.php\";s:11:\"new_version\";s:5:\"2.4.8\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/post-smtp/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/post-smtp.2.4.8.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/post-smtp/assets/icon-128x128.gif?rev=2758621\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/post-smtp/assets/banner-1544x500.jpg?rev=2742027\";s:2:\"1x\";s:64:\"https://ps.w.org/post-smtp/assets/banner-772x250.jpg?rev=2749492\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.9\";}s:29:\"wp-mail-smtp/wp_mail_smtp.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:26:\"w.org/plugins/wp-mail-smtp\";s:4:\"slug\";s:12:\"wp-mail-smtp\";s:6:\"plugin\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:11:\"new_version\";s:5:\"3.7.0\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wp-mail-smtp/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-mail-smtp.3.7.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-256x256.png?rev=1755440\";s:2:\"1x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-128x128.png?rev=1755440\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wp-mail-smtp/assets/banner-1544x500.jpg?rev=2811094\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-mail-smtp/assets/banner-772x250.jpg?rev=2811094\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.2\";}}s:7:\"checked\";a:6:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"6.1.4\";s:19:\"akismet/akismet.php\";s:3:\"5.1\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:7:\"5.7.5.1\";s:9:\"hello.php\";s:5:\"1.7.2\";s:26:\"post-smtp/postman-smtp.php\";s:5:\"2.4.8\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:5:\"3.7.0\";}}', 'no'),
(333, 'action_scheduler_hybrid_store_demarkation', '78', 'yes'),
(334, 'schema-ActionScheduler_StoreSchema', '6.0.1681765765', 'yes'),
(335, 'schema-ActionScheduler_LoggerSchema', '3.0.1681765765', 'yes'),
(336, 'wp_mail_smtp_initial_version', '3.7.0', 'no'),
(337, 'wp_mail_smtp_version', '3.7.0', 'no'),
(338, 'wp_mail_smtp', 'a:6:{s:4:\"mail\";a:6:{s:10:\"from_email\";s:0:\"\";s:9:\"from_name\";s:0:\"\";s:6:\"mailer\";s:5:\"gmail\";s:11:\"return_path\";b:0;s:16:\"from_email_force\";b:1;s:15:\"from_name_force\";b:0;}s:4:\"smtp\";a:7:{s:7:\"autotls\";b:1;s:4:\"auth\";b:0;s:4:\"host\";s:0:\"\";s:10:\"encryption\";s:4:\"none\";s:4:\"port\";i:25;s:4:\"user\";s:0:\"\";s:4:\"pass\";s:0:\"\";}s:7:\"general\";a:1:{s:29:\"summary_report_email_disabled\";b:0;}s:5:\"gmail\";a:2:{s:9:\"client_id\";s:0:\"\";s:13:\"client_secret\";s:0:\"\";}s:8:\"sendgrid\";a:1:{s:7:\"api_key\";s:0:\"\";}s:7:\"mailgun\";a:3:{s:7:\"api_key\";s:0:\"\";s:6:\"domain\";s:0:\"\";s:6:\"region\";s:2:\"US\";}}', 'no'),
(339, 'wp_mail_smtp_activated_time', '1681765765', 'no'),
(340, 'wp_mail_smtp_activated', 'a:1:{s:4:\"lite\";i:1681765765;}', 'yes'),
(343, 'action_scheduler_lock_async-request-runner', '1681765918', 'yes'),
(344, '_transient_timeout_as-post-store-dependencies-met', '1681852166', 'no'),
(345, '_transient_as-post-store-dependencies-met', 'yes', 'no'),
(347, 'wp_mail_smtp_migration_version', '5', 'yes'),
(348, 'wp_mail_smtp_debug_events_db_version', '1', 'yes'),
(349, 'wp_mail_smtp_activation_prevent_redirect', '1', 'yes'),
(350, 'wp_mail_smtp_setup_wizard_stats', 'a:3:{s:13:\"launched_time\";i:1681765775;s:14:\"completed_time\";i:0;s:14:\"was_successful\";b:0;}', 'no'),
(353, 'wp_mail_smtp_review_notice', 'a:2:{s:4:\"time\";i:1681765858;s:9:\"dismissed\";b:0;}', 'yes'),
(367, 'wp_mail_smtp_notifications', 'a:4:{s:6:\"update\";i:1681765886;s:4:\"feed\";a:0:{}s:6:\"events\";a:0:{}s:9:\"dismissed\";a:0:{}}', 'yes'),
(380, '_site_transient_timeout_theme_roots', '1681830115', 'no'),
(381, '_site_transient_theme_roots', 'a:1:{s:8:\"bzrepair\";s:7:\"/themes\";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_postmeta`
--

CREATE TABLE `wpt_postmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_postmeta`
--

INSERT INTO `wpt_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_attached_file', '2023/04/logo.png'),
(4, 5, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:165;s:6:\"height\";i:98;s:4:\"file\";s:16:\"2023/04/logo.png\";s:8:\"filesize\";i:12351;s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:15:\"logo-150x98.png\";s:5:\"width\";i:150;s:6:\"height\";i:98;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:10610;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(5, 6, '_wp_trash_meta_status', 'publish'),
(6, 6, '_wp_trash_meta_time', '1681225544'),
(25, 2, '_wp_trash_meta_status', 'publish'),
(26, 2, '_wp_trash_meta_time', '1681231817'),
(27, 2, '_wp_desired_post_slug', 'sample-page'),
(28, 3, '_wp_trash_meta_status', 'draft'),
(29, 3, '_wp_trash_meta_time', '1681231818'),
(30, 3, '_wp_desired_post_slug', 'privacy-policy'),
(32, 12, '_edit_lock', '1681328893:1'),
(33, 14, '_edit_lock', '1681231768:1'),
(34, 16, '_edit_lock', '1681231781:1'),
(35, 18, '_edit_lock', '1681231801:1'),
(36, 20, '_edit_lock', '1681231816:1'),
(84, 28, '_wp_trash_meta_status', 'publish'),
(85, 28, '_wp_trash_meta_time', '1681232574'),
(86, 30, 'maxgallery_type', 'image'),
(87, 30, 'maxgallery_template', 'image-tiles'),
(88, 30, '_edit_lock', '1681329100:1'),
(89, 31, 'maxgallery_type', 'image'),
(90, 31, 'maxgallery_template', 'image-tiles'),
(91, 31, '_edit_lock', '1681329189:1'),
(98, 33, '_form', '<div class=\"row\">\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\n<label class=\"form-label\"> *First & Last Name </label>\n    [text* user-name class:form-input]\n</div>\n\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\n<label class=\"form-label\"> *Email</label>\n    [email* email class:form-input] \n</div>\n\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\n<label class=\"form-label\"> *Phone</label>\n[tel* tel class:form-input]\n</div>\n\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\n<label class=\"form-label\"> *vehicle make</label>\n[text* vehicle-make class:form-input]\n</div>\n\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\n<label class=\"form-label\"> *vehicle model</label>\n[text* vehicle-model class:form-input]\n</div>\n\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\n<label class=\"form-label\"> *Vehicle type</label>\n[radio vehicle-type default:1 \"trailer\" \"semi-truck\"]\n</div>\n\n<div class=\"col-12 col-sm-4 form-div\">\n<label class=\"form-label\"> *What service are you requesting?</label>\n[text service-request class:form-input]\n</div>\n\n<div class=\"col-12 col-sm-8 form-div\">\n<label class=\"form-label\"> *tell us more</label>\n[text tell-us-more class:form-input]\n</div>\n</div>\n\n[submit \"Submit\"]'),
(99, 33, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:19:\"[_site_title] \"NEW\"\";s:6:\"sender\";s:38:\"[_site_title] <wordpress@bzrepair.com>\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:4:\"body\";s:260:\"From: [user-name] [email]\nSubject: [_site_title] \"[vehicle-make] [vehicle-model]\"\n\nMessage Body:\n[user-name]\n[email]\n[tel]\n[vehicle-make]\n[vehicle-model]\n[vehicle-type]\n[tell-us-more]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:17:\"Reply-To: [email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(100, 33, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:34:\"[_site_title] <wordpress@bzrepair>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:105:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(101, 33, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:27:\"Please fill out this field.\";s:16:\"invalid_too_long\";s:32:\"This field has a too long input.\";s:17:\"invalid_too_short\";s:33:\"This field has a too short input.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:31:\"The uploaded file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:12:\"invalid_date\";s:41:\"Please enter a date in YYYY-MM-DD format.\";s:14:\"date_too_early\";s:32:\"This field has a too early date.\";s:13:\"date_too_late\";s:31:\"This field has a too late date.\";s:14:\"invalid_number\";s:22:\"Please enter a number.\";s:16:\"number_too_small\";s:34:\"This field has a too small number.\";s:16:\"number_too_large\";s:34:\"This field has a too large number.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:30:\"Please enter an email address.\";s:11:\"invalid_url\";s:19:\"Please enter a URL.\";s:11:\"invalid_tel\";s:32:\"Please enter a telephone number.\";}'),
(102, 33, '_additional_settings', ''),
(103, 33, '_locale', 'en_US'),
(125, 36, '_edit_last', '1'),
(126, 36, '_edit_lock', '1681472554:1'),
(127, 37, '_wp_attached_file', '2023/04/s1-e1681831234124.png'),
(128, 37, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:963;s:4:\"file\";s:29:\"2023/04/s1-e1681831234124.png\";s:8:\"filesize\";i:2622054;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:29:\"s1-e1681831234124-300x289.png\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:186147;}s:5:\"large\";a:5:{s:4:\"file\";s:15:\"s1-1024x682.png\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1291920;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:29:\"s1-e1681831234124-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:54620;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:29:\"s1-e1681831234124-768x740.png\";s:5:\"width\";i:768;s:6:\"height\";i:740;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1052722;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(129, 36, '_thumbnail_id', '37'),
(130, 1, '_edit_lock', '1681472599:1'),
(131, 38, '_edit_last', '1'),
(132, 38, '_edit_lock', '1681832150:1'),
(134, 39, '_edit_last', '1'),
(135, 39, '_edit_lock', '1681832152:1'),
(136, 39, '_thumbnail_id', '37'),
(137, 40, '_edit_last', '1'),
(138, 40, '_edit_lock', '1681832180:1'),
(140, 41, '_edit_last', '1'),
(141, 41, '_edit_lock', '1681832356:1'),
(143, 42, '_edit_last', '1'),
(144, 42, '_edit_lock', '1681832219:1'),
(146, 43, '_edit_last', '1'),
(147, 43, '_edit_lock', '1681832222:1'),
(148, 43, '_thumbnail_id', '37'),
(149, 44, '_edit_last', '1'),
(150, 44, '_edit_lock', '1681832254:1'),
(152, 45, '_edit_last', '1'),
(153, 45, '_edit_lock', '1681832256:1'),
(154, 45, '_thumbnail_id', '37'),
(155, 46, '_edit_last', '1'),
(156, 46, '_edit_lock', '1681832324:1'),
(158, 47, '_edit_last', '1'),
(159, 47, '_edit_lock', '1681832326:1'),
(160, 47, '_thumbnail_id', '37'),
(161, 48, '_edit_last', '1'),
(162, 48, '_edit_lock', '1681832368:1'),
(164, 49, '_edit_last', '1'),
(165, 49, '_edit_lock', '1681832330:1'),
(166, 49, '_thumbnail_id', '37'),
(167, 50, '_edit_last', '1'),
(168, 50, '_edit_lock', '1681832379:1'),
(170, 51, '_edit_last', '1'),
(171, 51, '_edit_lock', '1681832293:1'),
(173, 52, '_wp_attached_file', '2023/04/header.png'),
(174, 52, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:929;s:4:\"file\";s:18:\"2023/04/header.png\";s:8:\"filesize\";i:2958924;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:18:\"header-300x145.png\";s:5:\"width\";i:300;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:91815;}s:5:\"large\";a:5:{s:4:\"file\";s:19:\"header-1024x495.png\";s:5:\"width\";i:1024;s:6:\"height\";i:495;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:910801;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:18:\"header-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:49303;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:18:\"header-768x372.png\";s:5:\"width\";i:768;s:6:\"height\";i:372;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:532782;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:19:\"header-1536x743.png\";s:5:\"width\";i:1536;s:6:\"height\";i:743;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1885509;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(191, 61, '_edit_lock', '1681560243:1'),
(192, 63, '_edit_last', '1'),
(193, 63, '_edit_lock', '1681750844:1'),
(194, 67, '_edit_last', '1'),
(195, 67, 'message', 'Sed ut pellentesque risus. Aliquam non cursus enim. Sed rutrum, nibh eget\r\naccumsan dapibus, libero dolor venenatis odio, quis finibus lacus ipsum sit amet\r\nsapien. Integer semper libero eget nisi volutpat iaculis. Integer gravida convallis,\r\nvelit, vel ullamcorper ex. egestas id. Suspendisse imperdiet varius nibh, eget\r\nefficitur metus porttitor sed. dignissim, nisl'),
(196, 67, '_message', 'field_643a937b38848'),
(197, 67, 'rating', '5'),
(198, 67, '_rating', 'field_643a93d738849'),
(199, 67, '_edit_lock', '1681560923:1'),
(200, 68, '_edit_last', '1'),
(201, 68, '_edit_lock', '1681560960:1'),
(202, 68, 'message', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minus, ad. Officiis asperiores fuga commodi illum excepturi, vitae doloremque unde harum voluptatem aperiam suscipit eos, sunt maiores tempora minima praesentium rerum!'),
(203, 68, '_message', 'field_643a937b38848'),
(204, 68, 'rating', '3'),
(205, 68, '_rating', 'field_643a93d738849'),
(206, 69, '_edit_last', '1'),
(207, 69, '_edit_lock', '1681560989:1'),
(208, 69, 'message', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores ipsum recusandae iste quia magni natus nostrum, suscipit saepe facilis tenetur inventore numquam ut debitis nobis sequi ratione consequuntur blanditiis aperiam.'),
(209, 69, '_message', 'field_643a937b38848'),
(210, 69, 'rating', '1'),
(211, 69, '_rating', 'field_643a93d738849'),
(212, 70, '_edit_last', '1'),
(213, 70, '_edit_lock', '1681561028:1'),
(214, 70, 'message', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. At assumenda fuga, reiciendis possimus porro odit accusamus commodi. Officiis reiciendis odio eius rerum fuga. Quidem commodi tempore aut ut facilis ad?'),
(215, 70, '_message', 'field_643a937b38848'),
(216, 70, 'rating', '2'),
(217, 70, '_rating', 'field_643a93d738849'),
(218, 71, '_edit_last', '1'),
(219, 71, '_edit_lock', '1681567017:1'),
(220, 71, 'message', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. A iure deleniti molestiae corporis adipisci cum dolorum itaque dolore laudantium? Ducimus repudiandae inventore eveniet sunt illum mollitia alias ut animi esse?'),
(221, 71, '_message', 'field_643a937b38848'),
(222, 71, 'rating', '4'),
(223, 71, '_rating', 'field_643a93d738849'),
(225, 72, '_menu_item_type', 'custom'),
(226, 72, '_menu_item_menu_item_parent', '0'),
(227, 72, '_menu_item_object_id', '72'),
(228, 72, '_menu_item_object', 'custom'),
(229, 72, '_menu_item_target', ''),
(230, 72, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(231, 72, '_menu_item_xfn', ''),
(232, 72, '_menu_item_url', '#about'),
(234, 73, '_menu_item_type', 'custom'),
(235, 73, '_menu_item_menu_item_parent', '0'),
(236, 73, '_menu_item_object_id', '73'),
(237, 73, '_menu_item_object', 'custom'),
(238, 73, '_menu_item_target', ''),
(239, 73, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(240, 73, '_menu_item_xfn', ''),
(241, 73, '_menu_item_url', '#services'),
(243, 74, '_menu_item_type', 'custom'),
(244, 74, '_menu_item_menu_item_parent', '0'),
(245, 74, '_menu_item_object_id', '74'),
(246, 74, '_menu_item_object', 'custom'),
(247, 74, '_menu_item_target', ''),
(248, 74, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(249, 74, '_menu_item_xfn', ''),
(250, 74, '_menu_item_url', '#careers'),
(252, 75, '_menu_item_type', 'custom'),
(253, 75, '_menu_item_menu_item_parent', '0'),
(254, 75, '_menu_item_object_id', '75'),
(255, 75, '_menu_item_object', 'custom'),
(256, 75, '_menu_item_target', ''),
(257, 75, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(258, 75, '_menu_item_xfn', ''),
(259, 75, '_menu_item_url', '#connect'),
(261, 76, '_menu_item_type', 'custom'),
(262, 76, '_menu_item_menu_item_parent', '0'),
(263, 76, '_menu_item_object_id', '76'),
(264, 76, '_menu_item_object', 'custom'),
(265, 76, '_menu_item_target', ''),
(266, 76, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(267, 76, '_menu_item_xfn', ''),
(268, 76, '_menu_item_url', '#contact'),
(270, 12, '_wp_trash_meta_status', 'publish'),
(271, 12, '_wp_trash_meta_time', '1681764174'),
(272, 12, '_wp_desired_post_slug', 'about'),
(273, 16, '_wp_trash_meta_status', 'publish'),
(274, 16, '_wp_trash_meta_time', '1681764174'),
(275, 16, '_wp_desired_post_slug', 'careers'),
(276, 18, '_wp_trash_meta_status', 'publish'),
(277, 18, '_wp_trash_meta_time', '1681764174'),
(278, 18, '_wp_desired_post_slug', 'connect'),
(279, 20, '_wp_trash_meta_status', 'publish'),
(280, 20, '_wp_trash_meta_time', '1681764174'),
(281, 20, '_wp_desired_post_slug', 'contact'),
(282, 14, '_wp_trash_meta_status', 'publish'),
(283, 14, '_wp_trash_meta_time', '1681764174'),
(284, 14, '_wp_desired_post_slug', 'services'),
(316, 33, '_config_errors', 'a:1:{s:11:\"mail.sender\";a:1:{i:0;a:2:{s:4:\"code\";i:103;s:4:\"args\";a:3:{s:7:\"message\";s:0:\"\";s:6:\"params\";a:0:{}s:4:\"link\";s:70:\"https://contactform7.com/configuration-errors/email-not-in-site-domain\";}}}}'),
(317, 78, '_menu_item_type', 'custom'),
(318, 78, '_menu_item_menu_item_parent', '0'),
(319, 78, '_menu_item_object_id', '78'),
(320, 78, '_menu_item_object', 'custom'),
(321, 78, '_menu_item_target', ''),
(322, 78, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(323, 78, '_menu_item_xfn', ''),
(324, 78, '_menu_item_url', '#'),
(326, 79, '_menu_item_type', 'custom'),
(327, 79, '_menu_item_menu_item_parent', '0'),
(328, 79, '_menu_item_object_id', '79'),
(329, 79, '_menu_item_object', 'custom'),
(330, 79, '_menu_item_target', ''),
(331, 79, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(332, 79, '_menu_item_xfn', ''),
(333, 79, '_menu_item_url', '#about'),
(335, 80, '_menu_item_type', 'custom'),
(336, 80, '_menu_item_menu_item_parent', '0'),
(337, 80, '_menu_item_object_id', '80'),
(338, 80, '_menu_item_object', 'custom'),
(339, 80, '_menu_item_target', ''),
(340, 80, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(341, 80, '_menu_item_xfn', ''),
(342, 80, '_menu_item_url', '#services'),
(344, 81, '_menu_item_type', 'custom'),
(345, 81, '_menu_item_menu_item_parent', '0'),
(346, 81, '_menu_item_object_id', '81'),
(347, 81, '_menu_item_object', 'custom'),
(348, 81, '_menu_item_target', ''),
(349, 81, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(350, 81, '_menu_item_xfn', ''),
(351, 81, '_menu_item_url', '#careers'),
(353, 82, '_menu_item_type', 'custom'),
(354, 82, '_menu_item_menu_item_parent', '0'),
(355, 82, '_menu_item_object_id', '82'),
(356, 82, '_menu_item_object', 'custom'),
(357, 82, '_menu_item_target', ''),
(358, 82, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(359, 82, '_menu_item_xfn', ''),
(360, 82, '_menu_item_url', '#connect'),
(362, 83, '_menu_item_type', 'custom'),
(363, 83, '_menu_item_menu_item_parent', '0'),
(364, 83, '_menu_item_object_id', '83'),
(365, 83, '_menu_item_object', 'custom'),
(366, 83, '_menu_item_target', ''),
(367, 83, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(368, 83, '_menu_item_xfn', ''),
(369, 83, '_menu_item_url', '#contact'),
(371, 84, '_menu_item_type', 'custom'),
(372, 84, '_menu_item_menu_item_parent', '0'),
(373, 84, '_menu_item_object_id', '84'),
(374, 84, '_menu_item_object', 'custom'),
(375, 84, '_menu_item_target', ''),
(376, 84, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(377, 84, '_menu_item_xfn', ''),
(378, 84, '_menu_item_url', '#'),
(379, 84, '_menu_item_orphaned', '1681820896'),
(380, 78, '_wp_old_date', '2023-04-17'),
(381, 79, '_wp_old_date', '2023-04-17'),
(382, 80, '_wp_old_date', '2023-04-17'),
(383, 81, '_wp_old_date', '2023-04-17'),
(384, 82, '_wp_old_date', '2023-04-17'),
(385, 83, '_wp_old_date', '2023-04-17'),
(386, 37, '_wp_attachment_backup_sizes', 'a:5:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1445;s:6:\"height\";i:963;s:4:\"file\";s:6:\"s1.png\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:14:\"s1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:54523;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:14:\"s1-300x200.png\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:137567;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:14:\"s1-768x512.png\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:760549;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:15:\"s1-1024x682.png\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1291920;}}'),
(388, 85, '_wp_attached_file', '2023/04/fleetowner_39086_truck_dark_clouds_getty-e1681832225255.png'),
(389, 85, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1001;s:6:\"height\";i:963;s:4:\"file\";s:67:\"2023/04/fleetowner_39086_truck_dark_clouds_getty-e1681832225255.png\";s:8:\"filesize\";i:1442817;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:67:\"fleetowner_39086_truck_dark_clouds_getty-e1681832225255-300x289.png\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:93458;}s:5:\"large\";a:5:{s:4:\"file\";s:53:\"fleetowner_39086_truck_dark_clouds_getty-1024x576.png\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:519096;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:67:\"fleetowner_39086_truck_dark_clouds_getty-e1681832225255-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:27579;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:67:\"fleetowner_39086_truck_dark_clouds_getty-e1681832225255-768x739.png\";s:5:\"width\";i:768;s:6:\"height\";i:739;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:467615;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:53:\"fleetowner_39086_truck_dark_clouds_getty-1536x864.png\";s:5:\"width\";i:1536;s:6:\"height\";i:864;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:977798;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(390, 38, '_thumbnail_id', '85'),
(391, 85, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1712;s:6:\"height\";i:963;s:4:\"file\";s:44:\"fleetowner_39086_truck_dark_clouds_getty.png\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:52:\"fleetowner_39086_truck_dark_clouds_getty-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:27737;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:52:\"fleetowner_39086_truck_dark_clouds_getty-300x169.png\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:56764;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:52:\"fleetowner_39086_truck_dark_clouds_getty-768x432.png\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:322177;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:53:\"fleetowner_39086_truck_dark_clouds_getty-1024x576.png\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:519096;}s:14:\"1536x1536-orig\";a:5:{s:4:\"file\";s:53:\"fleetowner_39086_truck_dark_clouds_getty-1536x864.png\";s:5:\"width\";i:1536;s:6:\"height\";i:864;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:977798;}}'),
(392, 86, '_wp_attached_file', '2023/04/HD-wallpaper-scania-black-streamline-sweden-truck-v8-e1681832750240.jpg'),
(393, 86, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:962;s:4:\"file\";s:79:\"2023/04/HD-wallpaper-scania-black-streamline-sweden-truck-v8-e1681832750240.jpg\";s:8:\"filesize\";i:105271;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:79:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-e1681832750240-300x289.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7526;}s:5:\"large\";a:5:{s:4:\"file\";s:65:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-1024x911.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:911;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47171;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:79:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-e1681832750240-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2822;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:79:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-e1681832750240-768x739.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:739;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33291;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(394, 40, '_thumbnail_id', '86'),
(395, 87, '_wp_attached_file', '2023/04/black-semi-truck-dark-12066503-e1681832720340.jpg'),
(396, 87, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:962;s:4:\"file\";s:57:\"2023/04/black-semi-truck-dark-12066503-e1681832720340.jpg\";s:8:\"filesize\";i:154409;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:57:\"black-semi-truck-dark-12066503-e1681832720340-300x289.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14658;}s:5:\"large\";a:5:{s:4:\"file\";s:43:\"black-semi-truck-dark-12066503-1024x725.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:725;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:55575;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:57:\"black-semi-truck-dark-12066503-e1681832720340-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7102;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:57:\"black-semi-truck-dark-12066503-e1681832720340-768x739.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:739;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:53280;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(397, 42, '_thumbnail_id', '87'),
(398, 88, '_wp_attached_file', '2023/04/84SajQ-e1681832800719.webp'),
(399, 88, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:962;s:4:\"file\";s:34:\"2023/04/84SajQ-e1681832800719.webp\";s:8:\"filesize\";i:177760;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:34:\"84SajQ-e1681832800719-300x289.webp\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:14088;}s:5:\"large\";a:5:{s:4:\"file\";s:20:\"84SajQ-1024x640.webp\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:76200;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:34:\"84SajQ-e1681832800719-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:5346;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:34:\"84SajQ-e1681832800719-768x739.webp\";s:5:\"width\";i:768;s:6:\"height\";i:739;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:55790;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:20:\"84SajQ-1536x960.webp\";s:5:\"width\";i:1536;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:137018;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(400, 44, '_thumbnail_id', '88'),
(401, 89, '_wp_attached_file', '2023/04/HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-e1681832660341.jpg'),
(402, 89, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:999;s:6:\"height\";i:962;s:4:\"file\";s:143:\"2023/04/HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-e1681832660341.jpg\";s:8:\"filesize\";i:317501;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:143:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-e1681832660341-300x289.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16632;}s:5:\"large\";a:5:{s:4:\"file\";s:129:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-1024x735.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:735;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:109247;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:143:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-e1681832660341-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5328;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:143:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-e1681832660341-768x740.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:740;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:87948;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(403, 51, '_thumbnail_id', '89'),
(404, 46, '_thumbnail_id', '86'),
(405, 90, '_wp_attached_file', '2023/04/volvo-trucks-evolution-volvo-fh16-dark-e1681832558612.jpg'),
(406, 90, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1001;s:6:\"height\";i:963;s:4:\"file\";s:65:\"2023/04/volvo-trucks-evolution-volvo-fh16-dark-e1681832558612.jpg\";s:8:\"filesize\";i:112180;s:5:\"sizes\";a:5:{s:6:\"medium\";a:5:{s:4:\"file\";s:65:\"volvo-trucks-evolution-volvo-fh16-dark-e1681832558612-300x289.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:8516;}s:5:\"large\";a:5:{s:4:\"file\";s:51:\"volvo-trucks-evolution-volvo-fh16-dark-1024x517.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:517;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23540;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:65:\"volvo-trucks-evolution-volvo-fh16-dark-e1681832558612-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3252;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:65:\"volvo-trucks-evolution-volvo-fh16-dark-e1681832558612-768x739.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:739;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:35674;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:51:\"volvo-trucks-evolution-volvo-fh16-dark-1536x776.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:776;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42395;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(407, 41, '_thumbnail_id', '90'),
(408, 48, '_thumbnail_id', '88'),
(409, 50, '_thumbnail_id', '86'),
(410, 90, '_wp_attachment_backup_sizes', 'a:6:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1907;s:6:\"height\";i:963;s:4:\"file\";s:42:\"volvo-trucks-evolution-volvo-fh16-dark.jpg\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:50:\"volvo-trucks-evolution-volvo-fh16-dark-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3354;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:50:\"volvo-trucks-evolution-volvo-fh16-dark-300x151.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:151;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3567;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:50:\"volvo-trucks-evolution-volvo-fh16-dark-768x388.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:388;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14943;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:51:\"volvo-trucks-evolution-volvo-fh16-dark-1024x517.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:517;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23540;}s:14:\"1536x1536-orig\";a:5:{s:4:\"file\";s:51:\"volvo-trucks-evolution-volvo-fh16-dark-1536x776.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:776;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42395;}}'),
(411, 89, '_wp_attachment_backup_sizes', 'a:5:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1342;s:6:\"height\";i:963;s:4:\"file\";s:120:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies.jpg\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:128:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5456;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:128:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-300x215.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:215;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11859;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:128:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-768x551.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:551;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:65924;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:129:\"HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies-1024x735.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:735;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:109247;}}'),
(412, 88, '_wp_attachment_backup_sizes', 'a:10:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1600;s:6:\"height\";i:1000;s:4:\"file\";s:11:\"84SajQ.webp\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:19:\"84SajQ-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:5300;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:19:\"84SajQ-300x188.webp\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:11296;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:19:\"84SajQ-768x480.webp\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:48740;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:20:\"84SajQ-1024x640.webp\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:76200;}s:14:\"1536x1536-orig\";a:5:{s:4:\"file\";s:20:\"84SajQ-1536x960.webp\";s:5:\"width\";i:1536;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:137018;}s:18:\"full-1681832800719\";a:3:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:26:\"84SajQ-e1681832692715.webp\";}s:23:\"thumbnail-1681832800719\";a:5:{s:4:\"file\";s:34:\"84SajQ-e1681832692715-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:5436;}s:20:\"medium-1681832800719\";a:5:{s:4:\"file\";s:34:\"84SajQ-e1681832692715-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:14458;}s:26:\"medium_large-1681832800719\";a:5:{s:4:\"file\";s:34:\"84SajQ-e1681832692715-768x768.webp\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:56428;}}'),
(413, 87, '_wp_attachment_backup_sizes', 'a:5:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1361;s:6:\"height\";i:963;s:4:\"file\";s:34:\"black-semi-truck-dark-12066503.jpg\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:42:\"black-semi-truck-dark-12066503-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7113;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:42:\"black-semi-truck-dark-12066503-300x212.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:212;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:10549;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:42:\"black-semi-truck-dark-12066503-768x543.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:543;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:36224;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:43:\"black-semi-truck-dark-12066503-1024x725.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:725;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:55575;}}'),
(414, 86, '_wp_attachment_backup_sizes', 'a:5:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:1082;s:6:\"height\";i:963;s:4:\"file\";s:56:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8.jpg\";}s:14:\"thumbnail-orig\";a:5:{s:4:\"file\";s:64:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2809;}s:11:\"medium-orig\";a:5:{s:4:\"file\";s:64:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-300x267.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6770;}s:17:\"medium_large-orig\";a:5:{s:4:\"file\";s:64:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-768x684.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:684;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30036;}s:10:\"large-orig\";a:5:{s:4:\"file\";s:65:\"HD-wallpaper-scania-black-streamline-sweden-truck-v8-1024x911.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:911;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47171;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_posts`
--

CREATE TABLE `wpt_posts` (
  `ID` bigint UNSIGNED NOT NULL,
  `post_author` bigint UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_posts`
--

INSERT INTO `wpt_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-04-11 14:25:46', '2023-04-11 14:25:46', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2023-04-11 14:25:46', '2023-04-11 14:25:46', '', 0, 'http://bzrepair/?p=1', 0, 'post', '', 1),
(2, 1, '2023-04-11 14:25:46', '2023-04-11 14:25:46', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://bzrepair/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2023-04-11 16:50:17', '2023-04-11 16:50:17', '', 0, 'http://bzrepair/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-04-11 14:25:46', '2023-04-11 14:25:46', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://bzrepair.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2023-04-11 16:50:18', '2023-04-11 16:50:18', '', 0, 'http://bzrepair/?page_id=3', 0, 'page', '', 0),
(5, 1, '2023-04-11 15:04:47', '2023-04-11 15:04:47', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2023-04-11 15:04:47', '2023-04-11 15:04:47', '', 0, 'http://bzrepair/wp-content/uploads/2023/04/logo.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2023-04-11 15:05:44', '2023-04-11 15:05:44', '{\n    \"site_icon\": {\n        \"value\": 5,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 15:05:44\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '1a6b31b8-1fae-4a85-b0fb-c73d0aa0b979', '', '', '2023-04-11 15:05:44', '2023-04-11 15:05:44', '', 0, 'http://bzrepair/2023/04/11/1a6b31b8-1fae-4a85-b0fb-c73d0aa0b979/', 0, 'customize_changeset', '', 0),
(9, 1, '2023-04-11 16:50:17', '2023-04-11 16:50:17', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://bzrepair/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2023-04-11 16:50:17', '2023-04-11 16:50:17', '', 2, 'http://bzrepair/?p=9', 0, 'revision', '', 0),
(10, 1, '2023-04-11 16:50:18', '2023-04-11 16:50:18', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://bzrepair.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2023-04-11 16:50:18', '2023-04-11 16:50:18', '', 3, 'http://bzrepair/?p=10', 0, 'revision', '', 0),
(12, 1, '2023-04-11 16:51:36', '2023-04-11 16:51:36', '', 'About', '', 'trash', 'closed', 'closed', '', 'about__trashed', '', '', '2023-04-17 20:42:54', '2023-04-17 20:42:54', '', 0, 'http://bzrepair/?page_id=12', 0, 'page', '', 0),
(13, 1, '2023-04-11 16:51:36', '2023-04-11 16:51:36', '', 'About', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2023-04-11 16:51:36', '2023-04-11 16:51:36', '', 12, 'http://bzrepair/?p=13', 0, 'revision', '', 0),
(14, 1, '2023-04-11 16:51:50', '2023-04-11 16:51:50', '', 'Services', '', 'trash', 'closed', 'closed', '', 'services__trashed', '', '', '2023-04-17 20:42:54', '2023-04-17 20:42:54', '', 0, 'http://bzrepair/?page_id=14', 0, 'page', '', 0),
(15, 1, '2023-04-11 16:51:50', '2023-04-11 16:51:50', '', 'Services', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2023-04-11 16:51:50', '2023-04-11 16:51:50', '', 14, 'http://bzrepair/?p=15', 0, 'revision', '', 0),
(16, 1, '2023-04-11 16:52:04', '2023-04-11 16:52:04', '', 'Careers', '', 'trash', 'closed', 'closed', '', 'careers__trashed', '', '', '2023-04-17 20:42:54', '2023-04-17 20:42:54', '', 0, 'http://bzrepair/?page_id=16', 0, 'page', '', 0),
(17, 1, '2023-04-11 16:52:04', '2023-04-11 16:52:04', '', 'Careers', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2023-04-11 16:52:04', '2023-04-11 16:52:04', '', 16, 'http://bzrepair/?p=17', 0, 'revision', '', 0),
(18, 1, '2023-04-11 16:52:23', '2023-04-11 16:52:23', '', 'Connect', '', 'trash', 'closed', 'closed', '', 'connect__trashed', '', '', '2023-04-17 20:42:54', '2023-04-17 20:42:54', '', 0, 'http://bzrepair/?page_id=18', 0, 'page', '', 0),
(19, 1, '2023-04-11 16:52:23', '2023-04-11 16:52:23', '', 'Connect', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-04-11 16:52:23', '2023-04-11 16:52:23', '', 18, 'http://bzrepair/?p=19', 0, 'revision', '', 0),
(20, 1, '2023-04-11 16:52:38', '2023-04-11 16:52:38', '', 'Contact', '', 'trash', 'closed', 'closed', '', 'contact__trashed', '', '', '2023-04-17 20:42:54', '2023-04-17 20:42:54', '', 0, 'http://bzrepair/?page_id=20', 0, 'page', '', 0),
(21, 1, '2023-04-11 16:52:38', '2023-04-11 16:52:38', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2023-04-11 16:52:38', '2023-04-11 16:52:38', '', 20, 'http://bzrepair/?p=21', 0, 'revision', '', 0),
(28, 1, '2023-04-11 17:02:54', '2023-04-11 17:02:54', '{\n    \"bzrepair::custom_logo\": {\n        \"value\": 5,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2023-04-11 17:02:54\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '9c6d5189-387a-4d13-a8a4-41b80120b94f', '', '', '2023-04-11 17:02:54', '2023-04-11 17:02:54', '', 0, 'http://bzrepair/2023/04/11/9c6d5189-387a-4d13-a8a4-41b80120b94f/', 0, 'customize_changeset', '', 0),
(29, 1, '2023-04-12 19:45:25', '2023-04-12 19:45:25', '<!-- wp:gallery {\"linkTo\":\"none\"} -->\n<figure class=\"wp-block-gallery has-nested-images columns-default is-cropped\"></figure>\n<!-- /wp:gallery -->', 'About', '', 'inherit', 'closed', 'closed', '', '12-autosave-v1', '', '', '2023-04-12 19:45:25', '2023-04-12 19:45:25', '', 12, 'http://bzrepair/?p=29', 0, 'revision', '', 0),
(30, 1, '2023-04-12 19:53:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-12 19:53:16', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=maxgallery&p=30', 0, 'maxgallery', '', 0),
(31, 1, '2023-04-12 19:55:05', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-12 19:55:05', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=maxgallery&p=31', 0, 'maxgallery', '', 0),
(33, 1, '2023-04-12 20:18:56', '2023-04-12 20:18:56', '<div class=\"row\">\r\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\r\n<label class=\"form-label\"> *First & Last Name </label>\r\n    [text* user-name class:form-input]\r\n</div>\r\n\r\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\r\n<label class=\"form-label\"> *Email</label>\r\n    [email* email class:form-input] \r\n</div>\r\n\r\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\r\n<label class=\"form-label\"> *Phone</label>\r\n[tel* tel class:form-input]\r\n</div>\r\n\r\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\r\n<label class=\"form-label\"> *vehicle make</label>\r\n[text* vehicle-make class:form-input]\r\n</div>\r\n\r\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\r\n<label class=\"form-label\"> *vehicle model</label>\r\n[text* vehicle-model class:form-input]\r\n</div>\r\n\r\n<div class=\"col-12 col-sm-6 col-xl-4 form-div\">\r\n<label class=\"form-label\"> *Vehicle type</label>\r\n[radio vehicle-type default:1 \"trailer\" \"semi-truck\"]\r\n</div>\r\n\r\n<div class=\"col-12 col-sm-4 form-div\">\r\n<label class=\"form-label\"> *What service are you requesting?</label>\r\n[text service-request class:form-input]\r\n</div>\r\n\r\n<div class=\"col-12 col-sm-8 form-div\">\r\n<label class=\"form-label\"> *tell us more</label>\r\n[text tell-us-more class:form-input]\r\n</div>\r\n</div>\r\n\r\n[submit \"Submit\"]\n1\n[_site_title] \"NEW\"\n[_site_title] <wordpress@bzrepair.com>\n[_site_admin_email]\nFrom: [user-name] [email]\r\nSubject: [_site_title] \"[vehicle-make] [vehicle-model]\"\r\n\r\nMessage Body:\r\n[user-name]\r\n[email]\r\n[tel]\r\n[vehicle-make]\r\n[vehicle-model]\r\n[vehicle-type]\r\n[tell-us-more]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [email]\n\n\n\n\n[_site_title] \"[your-subject]\"\n[_site_title] <wordpress@bzrepair>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.\nPlease enter a date in YYYY-MM-DD format.\nThis field has a too early date.\nThis field has a too late date.\nPlease enter a number.\nThis field has a too small number.\nThis field has a too large number.\nThe answer to the quiz is incorrect.\nPlease enter an email address.\nPlease enter a URL.\nPlease enter a telephone number.', 'Request service', '', 'publish', 'closed', 'closed', '', 'request-service', '', '', '2023-04-17 21:50:23', '2023-04-17 21:50:23', '', 0, 'http://bzrepair/?post_type=wpcf7_contact_form&#038;p=33', 0, 'wpcf7_contact_form', '', 0),
(34, 1, '2023-04-14 11:27:19', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-14 11:27:19', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=services&p=34', 0, 'services', '', 0),
(35, 1, '2023-04-14 11:27:41', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-14 11:27:41', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=services&p=35', 0, 'services', '', 0),
(36, 1, '2023-04-14 11:44:13', '2023-04-14 11:44:13', '', 'Complete suspension work', '', 'publish', 'closed', 'closed', '', 'complete-suspension-work', '', '', '2023-04-14 11:44:13', '2023-04-14 11:44:13', '', 0, 'http://bzrepair/?post_type=services&#038;p=36', 0, 'services', '', 0),
(37, 1, '2023-04-14 11:44:02', '2023-04-14 11:44:02', '', 's1', '', 'inherit', 'open', 'closed', '', 's1', '', '', '2023-04-14 11:44:02', '2023-04-14 11:44:02', '', 36, 'http://bzrepair/wp-content/uploads/2023/04/s1.png', 0, 'attachment', 'image/png', 0),
(38, 1, '2023-04-14 12:03:07', '2023-04-14 12:03:07', '', 'Complete transmission work + rebuild', '', 'publish', 'closed', 'closed', '', 'complete-transmission-work-rebuild', '', '', '2023-04-18 15:35:46', '2023-04-18 15:35:46', '', 0, 'http://bzrepair/?post_type=services&#038;p=38', 0, 'services', '', 0),
(39, 1, '2023-04-14 12:05:29', '2023-04-14 12:05:29', '', 'Engine work: Full in-frame and out-of-frame rebuild', '', 'publish', 'closed', 'closed', '', 'engine-work-full-in-frame-and-out-of-frame-rebuild', '', '', '2023-04-14 12:05:29', '2023-04-14 12:05:29', '', 0, 'http://bzrepair/?post_type=services&#038;p=39', 0, 'services', '', 0),
(40, 1, '2023-04-14 12:05:44', '2023-04-14 12:05:44', '', 'Diagnostics using dealer-level software', '', 'publish', 'closed', 'closed', '', 'diagnostics-using-dealer-level-software', '', '', '2023-04-18 15:38:42', '2023-04-18 15:38:42', '', 0, 'http://bzrepair/?post_type=services&#038;p=40', 0, 'services', '', 0),
(41, 1, '2023-04-14 12:06:00', '2023-04-14 12:06:00', '', 'Diagnostics for Volvo, Detroit DD-13, Detroit DD-15, Detroit DD-16, Detroit 60-Series, Cummins X15, Paccar engines', '', 'publish', 'closed', 'closed', '', 'diagnostics-for-volvo-detroit-dd-13-detroit-dd-15-detroit-dd-16-detroit-60-series-cummins-x15-paccar-engines', '', '', '2023-04-18 15:41:37', '2023-04-18 15:41:37', '', 0, 'http://bzrepair/?post_type=services&#038;p=41', 0, 'services', '', 0),
(42, 1, '2023-04-14 12:06:14', '2023-04-14 12:06:14', '', 'Full after-treatment diagnostics and work, including DOC and DPF cleaning', '', 'publish', 'closed', 'closed', '', 'full-after-treatment-diagnostics-and-work-including-doc-and-dpf-cleaning', '', '', '2023-04-18 15:39:14', '2023-04-18 15:39:14', '', 0, 'http://bzrepair/?post_type=services&#038;p=42', 0, 'services', '', 0),
(43, 1, '2023-04-14 12:06:26', '2023-04-14 12:06:26', '', 'ABS troubleshooting + repair', '', 'publish', 'closed', 'closed', '', 'abs-troubleshooting-repair', '', '', '2023-04-14 12:06:26', '2023-04-14 12:06:26', '', 0, 'http://bzrepair/?post_type=services&#038;p=43', 0, 'services', '', 0),
(44, 1, '2023-04-14 12:06:50', '2023-04-14 12:06:50', '', 'Electronic troubleshooting + repair', '', 'publish', 'closed', 'closed', '', 'electronic-troubleshooting-repair', '', '', '2023-04-18 15:39:49', '2023-04-18 15:39:49', '', 0, 'http://bzrepair/?post_type=services&#038;p=44', 0, 'services', '', 0),
(45, 1, '2023-04-14 12:07:03', '2023-04-14 12:07:03', '', 'Full rebuild of drive differentials', '', 'publish', 'closed', 'closed', '', 'full-rebuild-of-drive-differentials', '', '', '2023-04-14 12:07:03', '2023-04-14 12:07:03', '', 0, 'http://bzrepair/?post_type=services&#038;p=45', 0, 'services', '', 0),
(46, 1, '2023-04-14 12:07:15', '2023-04-14 12:07:15', '', 'Full AC diagnostics and repair', '', 'publish', 'closed', 'closed', '', 'full-ac-diagnostics-and-repair', '', '', '2023-04-18 15:41:07', '2023-04-18 15:41:07', '', 0, 'http://bzrepair/?post_type=services&#038;p=46', 0, 'services', '', 0),
(47, 1, '2023-04-14 12:07:28', '2023-04-14 12:07:28', '', 'Kingpin replacement', '', 'publish', 'closed', 'closed', '', 'kingpin-replacement', '', '', '2023-04-14 12:07:28', '2023-04-14 12:07:28', '', 0, 'http://bzrepair/?post_type=services&#038;p=47', 0, 'services', '', 0),
(48, 1, '2023-04-14 12:07:47', '2023-04-14 12:07:47', '', 'Full truck and trailer inspection', '', 'publish', 'closed', 'closed', '', 'full-truck-and-trailer-inspection', '', '', '2023-04-18 15:41:50', '2023-04-18 15:41:50', '', 0, 'http://bzrepair/?post_type=services&#038;p=48', 0, 'services', '', 0),
(49, 1, '2023-04-14 12:08:07', '2023-04-14 12:08:07', '', 'Official Texas State Inspection Station *NEW', '', 'publish', 'closed', 'closed', '', 'official-texas-state-inspection-station-new', '', '', '2023-04-14 12:08:07', '2023-04-14 12:08:07', '', 0, 'http://bzrepair/?post_type=services&#038;p=49', 0, 'services', '', 0),
(50, 1, '2023-04-14 12:08:21', '2023-04-14 12:08:21', '', 'Wrecker services *NEW', '', 'publish', 'closed', 'closed', '', 'wrecker-services-new', '', '', '2023-04-18 15:42:00', '2023-04-18 15:42:00', '', 0, 'http://bzrepair/?post_type=services&#038;p=50', 0, 'services', '', 0),
(51, 1, '2023-04-14 12:08:46', '2023-04-14 12:08:46', '', 'Technicians\' certifications include: refrigerant recycling, Cummins engine overhaul and rebuild, JOST Fifth wheel, Automotive technology II, Mack Trucks Academy etc.', '', 'publish', 'closed', 'closed', '', 'technicians-certifications-include-refrigerant-recycling-cummins-engine-overhaul-and-rebuild-jost-fifth-wheel-automotive-technology-ii-mack-trucks-academy-etc', '', '', '2023-04-18 15:40:35', '2023-04-18 15:40:35', '', 0, 'http://bzrepair/?post_type=services&#038;p=51', 0, 'services', '', 0),
(52, 1, '2023-04-14 13:28:03', '2023-04-14 13:28:03', '', 'header', '', 'inherit', 'open', 'closed', '', 'header', '', '', '2023-04-14 13:28:03', '2023-04-14 13:28:03', '', 38, 'http://bzrepair/wp-content/uploads/2023/04/header.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2023-04-15 12:06:09', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-15 12:06:09', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=review&p=61', 0, 'review', '', 0),
(62, 1, '2023-04-15 12:06:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-15 12:06:28', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=review&p=62', 0, 'review', '', 0),
(63, 1, '2023-04-15 12:10:29', '2023-04-15 12:10:29', 'a:8:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:6:\"review\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;}', 'Review', 'review', 'publish', 'closed', 'closed', '', 'group_643a937ab7430', '', '', '2023-04-15 12:16:39', '2023-04-15 12:16:39', '', 0, 'http://bzrepair/?post_type=acf-field-group&#038;p=63', 0, 'acf-field-group', '', 0),
(64, 1, '2023-04-15 12:10:29', '2023-04-15 12:10:29', 'a:11:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Message', 'message', 'publish', 'closed', 'closed', '', 'field_643a937b38848', '', '', '2023-04-15 12:16:39', '2023-04-15 12:16:39', '', 63, 'http://bzrepair/?post_type=acf-field&#038;p=64', 0, 'acf-field', '', 0),
(65, 1, '2023-04-15 12:10:29', '2023-04-15 12:10:29', 'a:13:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:6:\"number\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:3:\"min\";i:0;s:3:\"max\";i:5;s:11:\"placeholder\";s:0:\"\";s:4:\"step\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}', 'Rating', 'rating', 'publish', 'closed', 'closed', '', 'field_643a93d738849', '', '', '2023-04-15 12:10:29', '2023-04-15 12:10:29', '', 63, 'http://bzrepair/?post_type=acf-field&p=65', 1, 'acf-field', '', 0),
(66, 1, '2023-04-15 12:10:37', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-15 12:10:37', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?post_type=review&p=66', 0, 'review', '', 0),
(67, 1, '2023-04-15 12:17:42', '2023-04-15 12:17:42', '', 'Sharon Escobar', '', 'publish', 'closed', 'closed', '', 'sharon-escobar', '', '', '2023-04-15 12:17:42', '2023-04-15 12:17:42', '', 0, 'http://bzrepair/?post_type=review&#038;p=67', 0, 'review', '', 0),
(68, 1, '2023-04-15 12:18:21', '2023-04-15 12:18:21', '', 'Lilian Hart', '', 'publish', 'closed', 'closed', '', 'lilian-hart', '', '', '2023-04-15 12:18:21', '2023-04-15 12:18:21', '', 0, 'http://bzrepair/?post_type=review&#038;p=68', 0, 'review', '', 0),
(69, 1, '2023-04-15 12:18:50', '2023-04-15 12:18:50', '', 'Joseph Cline', '', 'publish', 'closed', 'closed', '', 'joseph-cline', '', '', '2023-04-15 12:18:50', '2023-04-15 12:18:50', '', 0, 'http://bzrepair/?post_type=review&#038;p=69', 0, 'review', '', 0),
(70, 1, '2023-04-15 12:19:21', '2023-04-15 12:19:21', '', 'Omari Mejia', '', 'publish', 'closed', 'closed', '', 'omari-mejia', '', '', '2023-04-15 12:19:21', '2023-04-15 12:19:21', '', 0, 'http://bzrepair/?post_type=review&#038;p=70', 0, 'review', '', 0),
(71, 1, '2023-04-15 12:19:44', '2023-04-15 12:19:44', '', 'Sulayman Guerrero', '', 'publish', 'closed', 'closed', '', 'sulayman-guerrero', '', '', '2023-04-15 12:19:44', '2023-04-15 12:19:44', '', 0, 'http://bzrepair/?post_type=review&#038;p=71', 0, 'review', '', 0),
(72, 1, '2023-04-17 20:42:21', '2023-04-17 20:40:57', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 0, 'http://bzrepair/?p=72', 1, 'nav_menu_item', '', 0),
(73, 1, '2023-04-17 20:42:21', '2023-04-17 20:40:57', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 0, 'http://bzrepair/?p=73', 2, 'nav_menu_item', '', 0),
(74, 1, '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 'Careers', '', 'publish', 'closed', 'closed', '', 'careers', '', '', '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 0, 'http://bzrepair/?p=74', 3, 'nav_menu_item', '', 0),
(75, 1, '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 'Connect', '', 'publish', 'closed', 'closed', '', 'connect', '', '', '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 0, 'http://bzrepair/?p=75', 4, 'nav_menu_item', '', 0),
(76, 1, '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2023-04-17 20:42:21', '2023-04-17 20:42:21', '', 0, 'http://bzrepair/?p=76', 5, 'nav_menu_item', '', 0),
(78, 1, '2023-04-18 15:18:41', '2023-04-17 22:00:29', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2023-04-18 15:18:41', '2023-04-18 15:18:41', '', 0, 'http://bzrepair/?p=78', 1, 'nav_menu_item', '', 0),
(79, 1, '2023-04-18 15:18:41', '2023-04-17 22:01:48', '', 'About', '', 'publish', 'closed', 'closed', '', 'about-2', '', '', '2023-04-18 15:18:41', '2023-04-18 15:18:41', '', 0, 'http://bzrepair/?p=79', 2, 'nav_menu_item', '', 0),
(80, 1, '2023-04-18 15:18:41', '2023-04-17 22:01:48', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services-2', '', '', '2023-04-18 15:18:41', '2023-04-18 15:18:41', '', 0, 'http://bzrepair/?p=80', 3, 'nav_menu_item', '', 0),
(81, 1, '2023-04-18 15:18:41', '2023-04-17 22:01:48', '', 'Careers', '', 'publish', 'closed', 'closed', '', 'careers-2', '', '', '2023-04-18 15:18:41', '2023-04-18 15:18:41', '', 0, 'http://bzrepair/?p=81', 4, 'nav_menu_item', '', 0),
(82, 1, '2023-04-18 15:18:41', '2023-04-17 22:01:48', '', 'Connect', '', 'publish', 'closed', 'closed', '', 'connect-2', '', '', '2023-04-18 15:18:41', '2023-04-18 15:18:41', '', 0, 'http://bzrepair/?p=82', 5, 'nav_menu_item', '', 0),
(83, 1, '2023-04-18 15:18:41', '2023-04-17 22:01:48', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact-2', '', '', '2023-04-18 15:18:41', '2023-04-18 15:18:41', '', 0, 'http://bzrepair/?p=83', 6, 'nav_menu_item', '', 0),
(84, 1, '2023-04-18 12:28:16', '0000-00-00 00:00:00', '', 'Towing service', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-04-18 12:28:16', '0000-00-00 00:00:00', '', 0, 'http://bzrepair/?p=84', 1, 'nav_menu_item', '', 0),
(85, 1, '2023-04-18 15:35:29', '2023-04-18 15:35:29', '', 'fleetowner_39086_truck_dark_clouds_getty', '', 'inherit', 'open', 'closed', '', 'fleetowner_39086_truck_dark_clouds_getty', '', '', '2023-04-18 15:35:29', '2023-04-18 15:35:29', '', 38, 'http://bzrepair/wp-content/uploads/2023/04/fleetowner_39086_truck_dark_clouds_getty.png', 0, 'attachment', 'image/png', 0),
(86, 1, '2023-04-18 15:38:34', '2023-04-18 15:38:34', '', 'HD-wallpaper-scania-black-streamline-sweden-truck-v8', '', 'inherit', 'open', 'closed', '', 'hd-wallpaper-scania-black-streamline-sweden-truck-v8', '', '', '2023-04-18 15:38:34', '2023-04-18 15:38:34', '', 40, 'http://bzrepair/wp-content/uploads/2023/04/HD-wallpaper-scania-black-streamline-sweden-truck-v8.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2023-04-18 15:39:01', '2023-04-18 15:39:01', '', 'black-semi-truck-dark-12066503', '', 'inherit', 'open', 'closed', '', 'black-semi-truck-dark-12066503', '', '', '2023-04-18 15:39:01', '2023-04-18 15:39:01', '', 42, 'http://bzrepair/wp-content/uploads/2023/04/black-semi-truck-dark-12066503.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2023-04-18 15:39:39', '2023-04-18 15:39:39', '', '84SajQ', '', 'inherit', 'open', 'closed', '', '84sajq', '', '', '2023-04-18 15:39:39', '2023-04-18 15:39:39', '', 44, 'http://bzrepair/wp-content/uploads/2023/04/84SajQ.webp', 0, 'attachment', 'image/webp', 0),
(89, 1, '2023-04-18 15:40:23', '2023-04-18 15:40:23', '', 'HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies', '', 'inherit', 'open', 'closed', '', 'hd-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies', '', '', '2023-04-18 15:40:23', '2023-04-18 15:40:23', '', 51, 'http://bzrepair/wp-content/uploads/2023/04/HD-wallpaper-optimus-prime-truck-transformers-roll-out-optimus-prime-transformers-entertainment-truck-autobot-movies.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2023-04-18 15:41:31', '2023-04-18 15:41:31', '', 'volvo-trucks-evolution-volvo-fh16-dark', '', 'inherit', 'open', 'closed', '', 'volvo-trucks-evolution-volvo-fh16-dark', '', '', '2023-04-18 15:41:31', '2023-04-18 15:41:31', '', 41, 'http://bzrepair/wp-content/uploads/2023/04/volvo-trucks-evolution-volvo-fh16-dark.jpg', 0, 'attachment', 'image/jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_termmeta`
--

CREATE TABLE `wpt_termmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_terms`
--

CREATE TABLE `wpt_terms` (
  `term_id` bigint UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_terms`
--

INSERT INTO `wpt_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top menu', 'top-menu', 0),
(3, 'Footer menu', 'footer-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_term_relationships`
--

CREATE TABLE `wpt_term_relationships` (
  `object_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_term_relationships`
--

INSERT INTO `wpt_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(72, 2, 0),
(73, 2, 0),
(74, 2, 0),
(75, 2, 0),
(76, 2, 0),
(78, 3, 0),
(79, 3, 0),
(80, 3, 0),
(81, 3, 0),
(82, 3, 0),
(83, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_term_taxonomy`
--

CREATE TABLE `wpt_term_taxonomy` (
  `term_taxonomy_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_term_taxonomy`
--

INSERT INTO `wpt_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 5),
(3, 3, 'nav_menu', '', 0, 6);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_usermeta`
--

CREATE TABLE `wpt_usermeta` (
  `umeta_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_usermeta`
--

INSERT INTO `wpt_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wpt_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wpt_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"7d07d1b915191e645952918442371d6f070ab84aa90dd727523b2686c75f24a8\";a:4:{s:10:\"expiration\";i:1681992229;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36\";s:5:\"login\";i:1681819429;}}'),
(17, 1, 'wpt_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'wpt_user-settings', 'libraryContent=browse'),
(19, 1, 'wpt_user-settings-time', '1681225549'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'nav_menu_recently_edited', '3'),
(23, 1, 'wpt_persisted_preferences', 'a:2:{s:14:\"core/edit-post\";a:2:{s:26:\"isComplementaryAreaVisible\";b:1;s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2023-04-11T16:50:28.410Z\";}'),
(24, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(25, 1, 'maxgalleria_review_notice', '2023-04-13'),
(26, 1, 'closedpostboxes_services', 'a:0:{}'),
(27, 1, 'metaboxhidden_services', 'a:1:{i:0;s:7:\"slugdiv\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_users`
--

CREATE TABLE `wpt_users` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_users`
--

INSERT INTO `wpt_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B4NlUiNkon6/zI4Byeb5072R35WJkV/', 'admin', 'qwerty@gmail.com', 'http://bzrepair', '2023-04-11 14:25:46', '', 0, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza`
--

CREATE TABLE `wpt_wpgmza` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `address` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pic` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link` varchar(2083) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `icon` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lat` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lng` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `anim` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `infoopen` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `approved` tinyint(1) DEFAULT '1',
  `retina` tinyint(1) DEFAULT '0',
  `type` tinyint(1) DEFAULT '0',
  `did` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sticky` tinyint(1) DEFAULT '0',
  `other_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `latlng` point DEFAULT NULL,
  `layergroup` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_wpgmza`
--

INSERT INTO `wpt_wpgmza` (`id`, `map_id`, `address`, `description`, `pic`, `link`, `icon`, `lat`, `lng`, `anim`, `title`, `infoopen`, `category`, `approved`, `retina`, `type`, `did`, `sticky`, `other_data`, `latlng`, `layergroup`) VALUES
(1, 1, 'California', '', '', '', '', '36.778261', '-119.4179323999', '', '', '', '', 1, 0, 0, '', 0, '', 0x0000000001010000004a60730e9e63424098608967bfda5dc0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_admin_notices`
--

CREATE TABLE `wpt_wpgmza_admin_notices` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci,
  `active_date` datetime DEFAULT NULL,
  `options` longtext COLLATE utf8mb4_unicode_520_ci,
  `dismissed` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_circles`
--

CREATE TABLE `wpt_wpgmza_circles` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `center` point DEFAULT NULL,
  `radius` float DEFAULT NULL,
  `color` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `opacity` float DEFAULT NULL,
  `lineColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lineOpacity` float DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `hoverEnabled` tinyint(1) DEFAULT '0',
  `ohFillColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ohLineColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ohFillOpacity` float DEFAULT NULL,
  `ohLineOpacity` float DEFAULT NULL,
  `link` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `layergroup` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_image_overlays`
--

CREATE TABLE `wpt_wpgmza_image_overlays` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `cornerA` point DEFAULT NULL,
  `cornerB` point DEFAULT NULL,
  `image` varchar(700) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `opacity` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_maps`
--

CREATE TABLE `wpt_wpgmza_maps` (
  `id` int NOT NULL,
  `map_title` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_width` varchar(6) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_height` varchar(6) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_start_lat` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_start_lng` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_start_location` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_start_zoom` int NOT NULL,
  `default_marker` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` int NOT NULL,
  `alignment` int NOT NULL,
  `directions_enabled` int NOT NULL,
  `styling_enabled` int NOT NULL,
  `styling_json` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `active` int NOT NULL,
  `kml` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `bicycle` int NOT NULL,
  `traffic` int NOT NULL,
  `dbox` int NOT NULL,
  `dbox_width` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `listmarkers` int NOT NULL,
  `listmarkers_advanced` int NOT NULL,
  `filterbycat` tinyint(1) NOT NULL,
  `ugm_enabled` int NOT NULL,
  `ugm_category_enabled` tinyint(1) NOT NULL,
  `fusion` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_width_type` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `map_height_type` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `mass_marker_support` int NOT NULL,
  `ugm_access` int NOT NULL,
  `order_markers_by` int NOT NULL,
  `order_markers_choice` int NOT NULL,
  `show_user_location` int NOT NULL,
  `default_to` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `other_settings` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_wpgmza_maps`
--

INSERT INTO `wpt_wpgmza_maps` (`id`, `map_title`, `map_width`, `map_height`, `map_start_lat`, `map_start_lng`, `map_start_location`, `map_start_zoom`, `default_marker`, `type`, `alignment`, `directions_enabled`, `styling_enabled`, `styling_json`, `active`, `kml`, `bicycle`, `traffic`, `dbox`, `dbox_width`, `listmarkers`, `listmarkers_advanced`, `filterbycat`, `ugm_enabled`, `ugm_category_enabled`, `fusion`, `map_width_type`, `map_height_type`, `mass_marker_support`, `ugm_access`, `order_markers_by`, `order_markers_choice`, `show_user_location`, `default_to`, `other_settings`) VALUES
(1, 'My first map', '100', '400', '45.950464398418106', '-109.81550500000003', '45.950464398418106,-109.81550500000003', 4, '', 0, 4, 0, 0, '', 0, '', 0, 0, 0, '', 0, 0, 0, 0, 0, '', '%', 'px', 0, 0, 0, 0, 0, '', 'a:6:{s:8:\"map_type\";i:1;s:15:\"sl_stroke_color\";s:7:\"#FF0000\";s:13:\"sl_fill_color\";s:7:\"#FF0000\";s:17:\"sl_stroke_opacity\";i:1;s:15:\"sl_fill_opacity\";d:0.5;s:15:\"transport_layer\";N;}');

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_point_labels`
--

CREATE TABLE `wpt_wpgmza_point_labels` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `center` point DEFAULT NULL,
  `fillColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lineColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `opacity` float DEFAULT NULL,
  `fontSize` varchar(3) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_polygon`
--

CREATE TABLE `wpt_wpgmza_polygon` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `polydata` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `innerpolydata` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `linecolor` varchar(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lineopacity` varchar(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fillcolor` varchar(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `opacity` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ohfillcolor` varchar(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ohlinecolor` varchar(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ohopacity` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `polyname` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `linethickness` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `layergroup` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_polylines`
--

CREATE TABLE `wpt_wpgmza_polylines` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `polydata` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `linecolor` varchar(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `linethickness` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `opacity` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `polyname` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `layergroup` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpgmza_rectangles`
--

CREATE TABLE `wpt_wpgmza_rectangles` (
  `id` int NOT NULL,
  `map_id` int NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci,
  `cornerA` point DEFAULT NULL,
  `cornerB` point DEFAULT NULL,
  `color` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `opacity` float DEFAULT NULL,
  `lineColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lineOpacity` float DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `hoverEnabled` tinyint(1) DEFAULT '0',
  `ohFillColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ohLineColor` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ohFillOpacity` float DEFAULT NULL,
  `ohLineOpacity` float DEFAULT NULL,
  `link` varchar(700) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `layergroup` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpmailsmtp_debug_events`
--

CREATE TABLE `wpt_wpmailsmtp_debug_events` (
  `id` int UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_520_ci,
  `initiator` text COLLATE utf8mb4_unicode_520_ci,
  `event_type` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wpt_wpmailsmtp_tasks_meta`
--

CREATE TABLE `wpt_wpmailsmtp_tasks_meta` (
  `id` bigint NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpt_wpmailsmtp_tasks_meta`
--

INSERT INTO `wpt_wpmailsmtp_tasks_meta` (`id`, `action`, `data`, `date`) VALUES
(1, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2023-04-17 21:11:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wpt_actionscheduler_actions`
--
ALTER TABLE `wpt_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`);

--
-- Indexes for table `wpt_actionscheduler_claims`
--
ALTER TABLE `wpt_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Indexes for table `wpt_actionscheduler_groups`
--
ALTER TABLE `wpt_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Indexes for table `wpt_actionscheduler_logs`
--
ALTER TABLE `wpt_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Indexes for table `wpt_commentmeta`
--
ALTER TABLE `wpt_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpt_comments`
--
ALTER TABLE `wpt_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wpt_links`
--
ALTER TABLE `wpt_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wpt_options`
--
ALTER TABLE `wpt_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wpt_postmeta`
--
ALTER TABLE `wpt_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpt_posts`
--
ALTER TABLE `wpt_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wpt_termmeta`
--
ALTER TABLE `wpt_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpt_terms`
--
ALTER TABLE `wpt_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wpt_term_relationships`
--
ALTER TABLE `wpt_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wpt_term_taxonomy`
--
ALTER TABLE `wpt_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wpt_usermeta`
--
ALTER TABLE `wpt_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpt_users`
--
ALTER TABLE `wpt_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wpt_wpgmza`
--
ALTER TABLE `wpt_wpgmza`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_admin_notices`
--
ALTER TABLE `wpt_wpgmza_admin_notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_circles`
--
ALTER TABLE `wpt_wpgmza_circles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_image_overlays`
--
ALTER TABLE `wpt_wpgmza_image_overlays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_maps`
--
ALTER TABLE `wpt_wpgmza_maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_point_labels`
--
ALTER TABLE `wpt_wpgmza_point_labels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_polygon`
--
ALTER TABLE `wpt_wpgmza_polygon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_polylines`
--
ALTER TABLE `wpt_wpgmza_polylines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpgmza_rectangles`
--
ALTER TABLE `wpt_wpgmza_rectangles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpmailsmtp_debug_events`
--
ALTER TABLE `wpt_wpmailsmtp_debug_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpt_wpmailsmtp_tasks_meta`
--
ALTER TABLE `wpt_wpmailsmtp_tasks_meta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wpt_actionscheduler_actions`
--
ALTER TABLE `wpt_actionscheduler_actions`
  MODIFY `action_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `wpt_actionscheduler_claims`
--
ALTER TABLE `wpt_actionscheduler_claims`
  MODIFY `claim_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wpt_actionscheduler_groups`
--
ALTER TABLE `wpt_actionscheduler_groups`
  MODIFY `group_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wpt_actionscheduler_logs`
--
ALTER TABLE `wpt_actionscheduler_logs`
  MODIFY `log_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wpt_commentmeta`
--
ALTER TABLE `wpt_commentmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_comments`
--
ALTER TABLE `wpt_comments`
  MODIFY `comment_ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpt_links`
--
ALTER TABLE `wpt_links`
  MODIFY `link_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_options`
--
ALTER TABLE `wpt_options`
  MODIFY `option_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=385;

--
-- AUTO_INCREMENT for table `wpt_postmeta`
--
ALTER TABLE `wpt_postmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=415;

--
-- AUTO_INCREMENT for table `wpt_posts`
--
ALTER TABLE `wpt_posts`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `wpt_termmeta`
--
ALTER TABLE `wpt_termmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_terms`
--
ALTER TABLE `wpt_terms`
  MODIFY `term_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wpt_term_taxonomy`
--
ALTER TABLE `wpt_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wpt_usermeta`
--
ALTER TABLE `wpt_usermeta`
  MODIFY `umeta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `wpt_users`
--
ALTER TABLE `wpt_users`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpt_wpgmza`
--
ALTER TABLE `wpt_wpgmza`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_admin_notices`
--
ALTER TABLE `wpt_wpgmza_admin_notices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_circles`
--
ALTER TABLE `wpt_wpgmza_circles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_image_overlays`
--
ALTER TABLE `wpt_wpgmza_image_overlays`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_maps`
--
ALTER TABLE `wpt_wpgmza_maps`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_point_labels`
--
ALTER TABLE `wpt_wpgmza_point_labels`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_polygon`
--
ALTER TABLE `wpt_wpgmza_polygon`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_polylines`
--
ALTER TABLE `wpt_wpgmza_polylines`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpgmza_rectangles`
--
ALTER TABLE `wpt_wpgmza_rectangles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpmailsmtp_debug_events`
--
ALTER TABLE `wpt_wpmailsmtp_debug_events`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpt_wpmailsmtp_tasks_meta`
--
ALTER TABLE `wpt_wpmailsmtp_tasks_meta`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
